package proj.dto;

import java.sql.Timestamp;

public class MemberDTO {

	private String id;
	private String pw;
	private String name;
	private String eMail1;
	private String eMail2;
	private Timestamp rDate;
	private String address;
	private String eMail_Check;
	private String admin;
	private String andr_address;
	private Timestamp andr_date;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String geteMail1() {
		return eMail1;
	}

	public void seteMail1(String eMail1) {
		this.eMail1 = eMail1;
	}

	public String geteMail2() {
		return eMail2;
	}

	public void seteMail2(String eMail2) {
		this.eMail2 = eMail2;
	}

	public Timestamp getrDate() {
		return rDate;
	}

	public void setrDate(Timestamp rDate) {
		this.rDate = rDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String geteMail_Check() {
		return eMail_Check;
	}

	public void seteMail_Check(String eMail_Check) {
		this.eMail_Check = eMail_Check;
	}

	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}

	public String getAndr_address() {
		return andr_address;
	}

	public void setAndr_address(String andr_address) {
		this.andr_address = andr_address;
	}

	public Timestamp getAndr_date() {
		return andr_date;
	}

	public void setAndr_date(Timestamp andr_date) {
		this.andr_date = andr_date;
	}

}