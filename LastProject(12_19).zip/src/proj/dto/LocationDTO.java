package proj.dto;

import java.sql.Timestamp;

public class LocationDTO {
	private String id;
	private String andr_address;
	private Timestamp andr_date;
	private String carrier;
	

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getAndr_address() {
		return andr_address;
	}
	public void setAndr_address(String andr_address) {
		this.andr_address = andr_address;
	}
	
	public Timestamp getAndr_date() {
		return andr_date;
	}
	public void setAndr_date(Timestamp andr_date) {
		this.andr_date = andr_date;
	}
	
	public String getCarrier() {
		return carrier;
	}
	
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
}
