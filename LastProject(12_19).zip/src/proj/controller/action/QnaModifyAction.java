package proj.controller.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import proj.controller.Action;
import proj.dao.QnaDAO;
import proj.dto.QnaDTO;



public class QnaModifyAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		QnaDTO qDto = new QnaDTO();
		
		qDto.setQseq(Integer.parseInt(request.getParameter("qseq")));
		qDto.setSubject(request.getParameter("subject"));
		qDto.setContent(request.getParameter("content"));
		QnaDAO qDao = QnaDAO.getInstance();
		qDao.modifyQna(qDto);
		new QnaListAction().execute(request, response);

	}
}