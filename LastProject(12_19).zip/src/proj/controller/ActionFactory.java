package proj.controller;

import proj.admin.controller.*;
import proj.controller.action.*;
import proj.controller.memberAction.*;

public class ActionFactory {
	private static ActionFactory instance = new ActionFactory();

	private ActionFactory() {
		super();
	}

	public static ActionFactory getInstance() {
		return instance;
	}

	public Action getAction(String command) {
		Action action = null;
		System.out.println("ActionFactory  :" + command);
		/*로그인부분*/
		if (command.equals("main")) {
			action = new MainPageAction();
		} else if (command.equals("index")) {
			action = new IndexAction();
		} else if (command.equals("id_check_form")) {
			action = new IdCheckFormAction();
		} else if (command.equals("join")) {
			action = new joinAction();
		} else if (command.equals("login")) {
			action = new LoginAction();
		} else if (command.equals("logout")) {
			action = new LogoutAction();
		} else if (command.equals("eMailCheckOk")) {
			action = new eMailCheckOkPage();
		} else if (command.equals("eMailCheckNo")) {
			action = new eMailCheckNoPage();
		} else if (command.equals("eMailCheck")) {
			action = new eMailCheckformAction();
		} else if (command.equals("eMailCheck_Next")) {
			action = new eMailCheckOk_NEXT();
		} else if (command.equals("Modify")) {
			action = new ModifyAction();
		}else if (command.equals("id_search_form")){
			action = new id_search_form();
		}else if (command.equals("id_search_page")) {
			action = new id_search_OkPage();
		}else if (command.equals("pw_search_form")) {
			action = new pw_search_form();
		}else if (command.equals("pw_search_page")) {
			action = new pw_search_OkPage();
		}else if(command.equals("delete_member")) {
			action =new delete_memberAction();
		}else if(command.equals("delete_member_form")) {
			action=new delete_memberformAction();
		}

		// board
		if (command.equals("health_page")) {
			action = new HealthPageAction();
		} else 	if (command.equals("board_list")) {
			action = new BoardListAction();
		} else if (command.equals("board_write_form")) {
			action = new BoardWriteFormAction();
		} else if (command.equals("board_write")) {
			action = new BoardWriteAction();
		} else if (command.equals("board_view")) {
			action = new BoardViewAction();
		} else if (command.equals("board_check_pass_form")) {
			action = new BoardCheckPassFormAction();
		} else if (command.equals("board_check_pass")) {
			action = new BoardCheckPassAction();
		} else if (command.equals("board_update_form")) {
			action = new BoardUpdateFormAction();
		} else if (command.equals("board_update")) {
			action = new BoardUpdateAction();
		} else if (command.equals("board_delete")) {
			action = new BoardDeleteAction();
		} else if (command.equals("boardmain")) {
			action = new BoardMainCheck();
		}else if (command.equals("diseaseList")) {
			action = new diseasePage();
		}else if (command.equals("boardListCheck")) {
			action = new BoardListCheck();
		}


		

		if (command.equals("qna_list")) {
			action = new QnaListAction();
		} else if (command.equals("qna_write_form")) {
			action = new QnaWriteFormAction();
		} else if (command.equals("qna_write")) {
			action = new QnaWriteAction();
		} else if (command.equals("qna_view")) {
			action = new QnaViewAction();
		} else if (command.equals("qna_modify")) {
			action = new QnaModifyAction();
		} else if (command.equals("qna_modify_form")) {
			action = new QnaModifyFormAction();
		} else if (command.equals("qna_delete")) {
			action = new QnaDeleteAction();
		}else if(command.equals("map_list")) {
			action=new MapListAction();
		}

		// 관리자용
		if (command.equals("admin_Loginform")) {
			action = new AdminLoginFormAction();
		} else if (command.equals("admin_Login")) {
			action = new AdminLoginAction();
		} else if (command.equals("admin_disease")) {
			action = new AdminIndexAction();
		} else if (command.equals("admin_logout")) {
			action = new AdminLogoutAction();
		} else if (command.equals("admin_health")) {
			action = new AdminHealthPage();
		} else if (command.equals("admin_memberlist")) {
			action = new AdaminMemberList();
		} else if (command.equals("admin_qna_list")) {
			action = new AdminQnaListAction();
		} else if (command.equals("admin_qna_detail")) {
			action = new AdminQnaDetailAction();
		} else if (command.equals("admin_qna_repsave")) {
			action = new AdminQnaResaveAction();
		} else if (command.equals("admin_main")) {
			action = new AdminMainAction();
		} else if (command.equals("admin_board_list")) {
			action = new AdminBoardListAction();
		} else if (command.equals("admin_disease_page")) {
			action = new AdminDiseasePageAction();
		} else if (command.equals("admin_setdisease_carrier")) {
			action = new AdminSetDiseaseCarrierAction();
		} else if (command.equals("admin_disease_check")) {
			action = new AdminDiseaseCheckAction();
		}
		return action;
	}
}