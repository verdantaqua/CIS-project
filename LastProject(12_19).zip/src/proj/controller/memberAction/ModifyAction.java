package proj.controller.memberAction;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import proj.controller.Action;
import proj.dao.MemberDAO;
import proj.dto.MemberDTO;

public class ModifyAction implements Action {
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
				
		HttpSession session = request.getSession();
		String id = session.getAttribute("id").toString();
				
		MemberDTO dto = new MemberDTO();
		dto.setId(id);
		dto.setPw(request.getParameter("pw"));
		dto.setName(request.getParameter("name"));
		dto.seteMail1(request.getParameter("eMail1"));
		dto.seteMail2(request.getParameter("eMail2"));
		dto.setAddress(request.getParameter("address"));
		
		
		MemberDAO dao = MemberDAO.getInstance();
		int ri = dao.updateMember(dto);

		
		if (ri == 1) {
			response.setCharacterEncoding("EUC-KR");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('정보수정이 완료되었습니다');");
			writer.println("document.location.href =\"main.jsp\";");
			writer.println("</script>");
			writer.flush();
			return;
		} else {
			response.setCharacterEncoding("EUC-KR");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('정보수정실패하였습니다..');");
			writer.println("history.go(-1);");
			writer.println("document.location.href =\"Login_main.jsp\";");
			writer.println("</script>");
			writer.flush();
			return;

		}

	}
}