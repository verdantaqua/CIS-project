package proj.admin.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.LocationDAO;
import proj.dto.LocationDTO;

public class AdminSetDiseaseCarrierAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String url = "admin/admin_disease.jsp";

		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		session.setAttribute("id", id);
		System.out.println(id);
		
		String carrier_id = request.getParameter("admin_carrier_name");
		String disease_name = request.getParameter("admin_disease_name");

		session.setAttribute("admin_disease_name", disease_name);
		
		LocationDAO dao = LocationDAO.getInstance();
		
		int r = dao.setdiseaseCarrier(carrier_id,disease_name);
		
		System.out.println("r : " + r);
		
		ArrayList<LocationDTO> dto = dao.getdisease(carrier_id);
		request.setAttribute("dtos", dto);
		
		session.setAttribute("admin_disease_id", carrier_id);
		
		request.getRequestDispatcher(url).forward(request, response);
	}

}
