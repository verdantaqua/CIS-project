package proj.admin.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.QnaDAO;
import proj.dto.QnaDTO;



public class AdminQnaDetailAction implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		 	
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("id");
		session.setAttribute("id", id);
		//관리자가 게시글을 눌렀을때 
	String url = "admin/admin_qnaDetail.jsp";
    String qseq = request.getParameter("qseq").trim();
    System.out.println(qseq);
		    QnaDAO qDao = QnaDAO.getInstance();
		    QnaDTO qDto = qDao.getQna(Integer.parseInt(qseq));
		    request.setAttribute("qDto", qDto);
		    request.getRequestDispatcher(url).forward(request, response);
		    
		    
		    

			
	}

}
