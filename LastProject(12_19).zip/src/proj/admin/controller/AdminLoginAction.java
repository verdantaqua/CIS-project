package proj.admin.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import proj.controller.Action;
import proj.dao.MemberDAO;
import proj.dto.MemberDTO;



public class AdminLoginAction implements Action {

	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		MemberDAO dao = MemberDAO.getInstance();
		int UserNum = dao.userCheck(id, pw);
		int adminNum = dao.adminCheck(id);
		if (UserNum == -1) {
			response.setCharacterEncoding("UTF-8");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('아이디가 존재하지않습니다.');");
			writer.println("history.back();");
			writer.println("</script>");
			writer.flush();
			return;
		} else if (UserNum == 0) {
			response.setCharacterEncoding("UTF-8");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('비밀번호틀렸대');");
			writer.println("history.back();");
			writer.println("</script>");
			writer.flush();
			return;

		} else if (adminNum == -1) {

			response.setCharacterEncoding("UTF-8");
			PrintWriter writer = response.getWriter();
			writer.println("<script type='text/javascript'>");
			writer.println("alert('관리자가아닙니다!');");
			writer.println("history.back();");
			writer.println("</script>");
			writer.flush();
			return;
		} else {
			MemberDTO dto = dao.getMember(id);
			String name = dto.getName();

			session.setAttribute("id", id);
			session.setAttribute("name", name);
			session.setAttribute("ValidMem", "yes");

			response.sendRedirect("DiseaseServlet?command=admin_main");
		}
	}

}
