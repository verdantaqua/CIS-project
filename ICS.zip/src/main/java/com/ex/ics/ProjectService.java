package com.ex.ics;

import java.util.List;

import com.ex.ics.ProjectDTO;

public interface ProjectService {
	List selectProjectList() throws Exception;
}
