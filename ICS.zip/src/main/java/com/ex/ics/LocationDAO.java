package com.ex.ics;

import java.util.List;

public interface LocationDAO {

}
