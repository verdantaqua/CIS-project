package com.ex.ics;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("projectService")
public class ProjectServiceImpl implements ProjectService{
	@Autowired
	private ProjectDAO projectMapper;

	@Override
	@Transactional
	public List selectProjectList() throws Exception {
		// TODO Auto-generated method stub
		return projectMapper.selectProjectList();
	}
	
	
}
