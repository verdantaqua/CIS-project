package com.ex.ics;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;



public class ProjectSelect {
	
	private static SqlSessionFactory sesFact = null;
	
	public ProjectDTO projectSelect(String id) {
		
		Properties prop = new Properties();
		prop.setProperty("driver", "oracle.jdbc.driver.OracleDriver");
		prop.setProperty("url", "jdbc:oracle:thin:@127.0.0.1:1521:xe");
		prop.setProperty("user", "project");
		prop.setProperty("password", "1234");

		MyDataSourceFactory mdsf = new MyDataSourceFactory();
		mdsf.setProperties(prop);
		DataSource ds = mdsf.getDataSource();

		TransactionFactory trFact = new JdbcTransactionFactory();
		Environment environment = new Environment("development", trFact, ds);
		Configuration config = new Configuration(environment);
		config.addMapper(MyMapper.class);

		sesFact = new SqlSessionFactoryBuilder().build(config);
		
		ProjectDTO temp;
		
		try (SqlSession session = sesFact.openSession()) {

			temp = session.selectOne("slectProjectDTO", id);
			if (temp == null) {
				System.out.println("왜 없냐...?");
			} else {

				System.out.println("userID  : " + temp.getId());
			}
		}
		
		return temp;
		
	}
}
