package com.ex.ics;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

public interface MyMapper {
	@Select("SELECT * FROM Project where id =#{id}")
	ProjectDTO slectProjectDTO(String id);
    
	@Insert("insert into location(id,andr_address,andr_date,carrier) values(#{id},#{andr_address},sysdate,'no')")
	void insertLocation(LocationDTO locationdto);
}
