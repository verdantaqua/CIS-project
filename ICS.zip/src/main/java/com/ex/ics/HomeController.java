package com.ex.ics;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

		return "home";
	}

	@RequestMapping(value = "/android1", produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Map androidTestWithRequestAndResponse(HttpServletRequest request) {

		String appID = request.getParameter("appID");
		String appPW = request.getParameter("appPW");
		System.out.println(appID);
		System.out.println(appPW);

		ProjectSelect projectselect = new ProjectSelect();

		ProjectDTO projectdto = projectselect.projectSelect(appID);

		Map result = new HashMap();
		if (result != null) {
			result.put("data1", projectdto.getId());
			result.put("data2", projectdto.getPw());
		}
		return result;
	}

	@RequestMapping("/android2")
	public void androidTestWithRequest(HttpServletRequest request) {

		String id = request.getParameter("id");
		String andr_address = request.getParameter("andr_address");

		// String id = "바보";
		// String andr_address = "안드로메다 c-136 지구";

		LocationInsert linsert = new LocationInsert();
		linsert.locationInsert(id, andr_address);

	}

}
