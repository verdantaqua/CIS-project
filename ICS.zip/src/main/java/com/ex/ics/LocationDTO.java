package com.ex.ics;

import java.sql.Timestamp;

public class LocationDTO {
	String id;
	String andr_address;
	Timestamp andr_date;
	
	public LocationDTO(String id2, String andr_address2, Timestamp andr_date2) {
		this.id = id2;
		this.andr_address = andr_address2;
		this.andr_date = andr_date2;
		
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAndr_address() {
		return andr_address;
	}
	public void setAndr_address(String andr_address) {
		this.andr_address = andr_address;
	}
	
	public Timestamp getAndr_date() {
		return andr_date;
	}
	public void setAndr_date(Timestamp andr_date) {
		this.andr_date = andr_date;
	}
}
