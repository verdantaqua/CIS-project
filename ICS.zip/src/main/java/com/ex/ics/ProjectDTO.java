package com.ex.ics;

import java.sql.Timestamp;

public class ProjectDTO {

	private String id;
	private String pw;
	private String name;
	private String eMail1;
	private String eMail2;
	private String address;
	private Timestamp rdate;
	private String eMaile_check;
	private String admin;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String geteMail1() {
		return eMail1;
	}
	public void seteMail1(String eMail1) {
		this.eMail1 = eMail1;
	}
	public String geteMail2() {
		return eMail2;
	}
	public void seteMail2(String eMail2) {
		this.eMail2 = eMail2;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Timestamp getRdate() {
		return rdate;
	}
	public void setRdate(Timestamp rdate) {
		this.rdate = rdate;
	}
	public String geteMaile_check() {
		return eMaile_check;
	}
	public void seteMaile_check(String eMaile_check) {
		this.eMaile_check = eMaile_check;
	}
	public String getAdmin() {
		return admin;
	}
	public void setAdmin(String admin) {
		this.admin = admin;
	}
}
